__all__ = [
    "wilcoxon_test",
]

from malenia.results.stats.statistical_tests import wilcoxon_test
