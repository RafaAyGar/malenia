__all__ = [
    "Results",
]

from malenia.results.results import Results
