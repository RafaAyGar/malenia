__all__ = ["OBDForest"]

from malenia.methods._binary_decomposition_forest import OBDForest
